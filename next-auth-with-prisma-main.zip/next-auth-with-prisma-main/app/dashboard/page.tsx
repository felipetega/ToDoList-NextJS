export default async function Dashboard() {
  return <>Super Secret Page</>
}
